import os
import sqlite3
from datetime import datetime
from config import DATABASE_PATH

def get_connection():
    directory = os.path.dirname(DATABASE_PATH)
    if directory:
        os.makedirs(directory, exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS opportunities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            url TEXT UNIQUE NOT NULL,
            source TEXT,
            category TEXT,
            description TEXT,
            status TEXT,
            score INTEGER DEFAULT 0,
            published_at TEXT,
            discovered_at TEXT NOT NULL,
            updated_at TEXT,
            is_sardinia INTEGER DEFAULT 0,
            is_transport INTEGER DEFAULT 0,
            is_artisan INTEGER DEFAULT 0,
            is_relevant INTEGER DEFAULT 0,
            notified INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()

def insert_opportunity(item):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO opportunities
            (title,url,source,category,description,status,score,published_at,
             discovered_at,updated_at,is_sardinia,is_transport,is_artisan,
             is_relevant,notified)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            item["title"], item["url"], item.get("source",""),
            item.get("category",""), item.get("description",""),
            item.get("status","DA VERIFICARE"), item.get("score",0),
            item.get("published_at",""), datetime.utcnow().isoformat(),
            item.get("updated_at",""), int(item.get("is_sardinia",False)),
            int(item.get("is_transport",False)), int(item.get("is_artisan",False)),
            int(item.get("is_relevant",False)), 0
        ))
        conn.commit()
        inserted = True
    except sqlite3.IntegrityError:
        inserted = False
    conn.close()
    return inserted

def get_opportunities(limit=15, only_relevant=True):
    conn = get_connection()
    query = """
        SELECT * FROM opportunities
        WHERE is_relevant = 1
        ORDER BY score DESC, discovered_at DESC LIMIT ?
    """ if only_relevant else """
        SELECT * FROM opportunities
        ORDER BY discovered_at DESC LIMIT ?
    """
    rows = conn.execute(query, (limit,)).fetchall()
    conn.close()
    return rows

def get_by_category(category, limit=15):
    conn = get_connection()
    rows = conn.execute("""
        SELECT * FROM opportunities
        WHERE is_relevant=1 AND category LIKE ?
        ORDER BY score DESC, discovered_at DESC LIMIT ?
    """, (f"%{category}%", limit)).fetchall()
    conn.close()
    return rows

def get_new_unnotified(limit=15):
    conn = get_connection()
    rows = conn.execute("""
        SELECT * FROM opportunities
        WHERE is_relevant=1 AND notified=0
        ORDER BY score DESC, discovered_at DESC LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return rows

def mark_notified(opportunity_id):
    conn = get_connection()
    conn.execute("UPDATE opportunities SET notified=1 WHERE id=?", (opportunity_id,))
    conn.commit()
    conn.close()
