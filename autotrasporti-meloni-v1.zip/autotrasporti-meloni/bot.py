from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from config import TELEGRAM_BOT_TOKEN, MAX_RESULTS
from database import init_database, get_opportunities, get_by_category

def format_row(row):
    return (
        f"#{row['id']} ⭐ {row['score']}/100\n"
        f"🚛 {row['title']}\n"
        f"📂 {row['category']}\n"
        f"📌 {row['status']}\n"
        f"🏛 {row['source']}\n"
        f"🔗 {row['url']}\n"
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""🚛 AUTOTRASPORTI MELONI

Radar incentivi, contributi e normativa per autotrasporto/artigianato.

/nuovi      → ultime opportunità
/tutti      → archivio
/scadenze   → misure da verificare
/camion     → camion e veicoli
/gasolio    → carburanti e accise
/rimessa    → immobili/rimesse
/energia    → energia
/formazione → formazione/personale
/aggiorna   → stato sistema""")

async def list_rows(update, rows, title):
    if not rows:
        await update.message.reply_text("🔎 Nessun risultato.")
        return
    message = f"{title}\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for row in rows:
        message += format_row(row) + "\n"
    await update.message.reply_text(message, disable_web_page_preview=True)

async def nuovi(update, context):
    await list_rows(update, get_opportunities(MAX_RESULTS, True), "🚛 NUOVE OPPORTUNITÀ")

async def tutti(update, context):
    await list_rows(update, get_opportunities(MAX_RESULTS, False), "📚 ARCHIVIO")

async def scadenze(update, context):
    rows = [r for r in get_opportunities(MAX_RESULTS, True) if r["status"] != "CHIUSO"]
    await list_rows(update, rows, "📅 SCADENZE / MISURE ATTIVE")

async def category(update, context, name, title):
    await list_rows(update, get_by_category(name, MAX_RESULTS), title)

async def camion(update, context): await category(update, context, "CAMION/VEICOLI", "🚚 CAMION / VEICOLI")
async def gasolio(update, context): await category(update, context, "GASOLIO/CARBURANTI", "⛽ GASOLIO / CARBURANTI")
async def rimessa(update, context): await category(update, context, "IMMOBILI/RIMESSE", "🏭 RIMESSE / CAPANNONI")
async def energia(update, context): await category(update, context, "ENERGIA", "⚡ ENERGIA")
async def formazione(update, context): await category(update, context, "FORMAZIONE/PERSONALE", "👷 FORMAZIONE / PERSONALE")

async def aggiorna(update, context):
    await update.message.reply_text("🔄 Il sistema viene aggiornato dal motore di scansione.")

def main():
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN non configurato.")
    init_database()
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    for command, handler in {
        "start": start, "nuovi": nuovi, "tutti": tutti, "scadenze": scadenze,
        "camion": camion, "gasolio": gasolio, "rimessa": rimessa,
        "energia": energia, "formazione": formazione, "aggiorna": aggiorna,
    }.items():
        app.add_handler(CommandHandler(command, handler))
    print("AUTOTRASPORTI MELONI TELEGRAM BOT AVVIATO")
    app.run_polling()

if __name__ == "__main__":
    main()
