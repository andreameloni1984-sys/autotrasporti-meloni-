from config import (
    REGION_KEYWORDS, TRANSPORT_KEYWORDS, ARTISAN_KEYWORDS,
    VEHICLE_KEYWORDS, FUEL_KEYWORDS, PROPERTY_KEYWORDS,
    ENERGY_KEYWORDS, PEOPLE_KEYWORDS, FINANCE_KEYWORDS,
    EXCLUDE_KEYWORDS,
)

def normalize(text):
    return " ".join((text or "").lower().split())

def contains_any(text, keywords):
    return any(keyword.lower() in text for keyword in keywords)

def classify(text):
    text = normalize(text)
    categories = []
    if contains_any(text, VEHICLE_KEYWORDS):
        categories.append("CAMION/VEICOLI")
    if contains_any(text, FUEL_KEYWORDS):
        categories.append("GASOLIO/CARBURANTI")
    if contains_any(text, PROPERTY_KEYWORDS):
        categories.append("IMMOBILI/RIMESSE")
    if contains_any(text, ENERGY_KEYWORDS):
        categories.append("ENERGIA")
    if contains_any(text, PEOPLE_KEYWORDS):
        categories.append("FORMAZIONE/PERSONALE")
    if contains_any(text, FINANCE_KEYWORDS):
        categories.append("FINANZA/INCENTIVI")
    if not categories:
        categories.append("ALTRO")
    return categories

def analyze_relevance(title, description="", source=""):
    text = normalize(f"{title} {description} {source}")
    sardinia = contains_any(text, REGION_KEYWORDS)
    transport = contains_any(text, TRANSPORT_KEYWORDS + VEHICLE_KEYWORDS)
    artisan = contains_any(text, ARTISAN_KEYWORDS)
    category_list = classify(text)
    score = 0
    if sardinia: score += 30
    if transport: score += 30
    if artisan: score += 15
    if contains_any(text, FINANCE_KEYWORDS): score += 10
    if contains_any(text, VEHICLE_KEYWORDS): score += 10
    if contains_any(text, FUEL_KEYWORDS): score += 10
    if contains_any(text, PROPERTY_KEYWORDS): score += 8
    if contains_any(text, ENERGY_KEYWORDS): score += 8
    if contains_any(text, PEOPLE_KEYWORDS): score += 5
    excluded = contains_any(text, EXCLUDE_KEYWORDS)
    if excluded and not transport and not artisan:
        score -= 20
    relevant = score >= 30 or (sardinia and artisan) or (sardinia and transport)
    return {
        "score": max(0, min(score, 100)),
        "is_sardinia": sardinia,
        "is_transport": transport,
        "is_artisan": artisan,
        "is_relevant": relevant,
        "categories": category_list,
    }
