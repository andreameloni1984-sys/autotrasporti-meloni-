# 🚛 AUTOTRASPORTI MELONI

Sistema di monitoraggio per imprese artigiane di autotrasporto, con focus Sardegna.

## Funzioni V1
- contributi e incentivi
- rimborsi e crediti d'imposta
- carburanti e accise
- camion e rinnovo mezzi
- rimesse, capannoni e officine
- energia e fotovoltaico
- formazione e sicurezza
- normativa

## Telegram
/start
/nuovi
/tutti
/scadenze
/camion
/gasolio
/rimessa
/energia
/formazione
/aggiorna

## Secrets GitHub
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID

Non inserire token o password nei file del repository.
