import hashlib
import re
from datetime import datetime
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from config import REQUEST_TIMEOUT
from database import init_database, insert_opportunity
from filters import analyze_relevance
from sources import SOURCES

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; AutotrasportiMeloniBot/1.0)"}

def clean_text(text):
    return re.sub(r"\s+", " ", text or "").strip()

def detect_status(text):
    text = text.lower()
    if any(x in text for x in ["scadenza", "domande entro", "presentazione delle domande",
                               "apertura", "domande aperte"]):
        return "APERTO/DA VERIFICARE"
    if any(x in text for x in ["proroga", "prorogato", "riapertura", "rifinanziamento"]):
        return "PROROGA/RIAPERTURA"
    if any(x in text for x in ["chiuso", "scaduto", "termini scaduti"]):
        return "CHIUSO"
    return "DA VERIFICARE"

def fetch_page(source):
    try:
        response = requests.get(source["url"], headers=HEADERS, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        return response.text
    except Exception as exc:
        print(f"[WARN] {source['name']}: {exc}")
        return None

def extract_links(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    results = []
    for link in soup.find_all("a", href=True):
        title = clean_text(link.get_text(" ", strip=True))
        href = link.get("href")
        if not title or not href:
            continue
        absolute_url = urljoin(base_url, href)
        if absolute_url.startswith("http"):
            results.append({"title": title, "url": absolute_url})
    return results

def scan_source(source):
    html = fetch_page(source)
    if not html:
        return []
    links = extract_links(html, source["url"])
    results = []
    for link in links:
        analysis = analyze_relevance(link["title"], "", source["name"])
        if not analysis["is_relevant"]:
            continue
        results.append({
            "title": link["title"][:500],
            "url": link["url"],
            "source": source["name"],
            "category": ", ".join(analysis["categories"]),
            "description": "",
            "status": detect_status(f"{link['title']} {source['name']}"),
            "score": analysis["score"],
            "published_at": "",
            "updated_at": "",
            "is_sardinia": analysis["is_sardinia"],
            "is_transport": analysis["is_transport"],
            "is_artisan": analysis["is_artisan"],
            "is_relevant": analysis["is_relevant"],
        })
    return results

def run_scan():
    print("=" * 60)
    print("AUTOTRASPORTI MELONI - SCANNER")
    print(datetime.now().isoformat())
    print("=" * 60)
    init_database()
    total_found = total_new = 0
    for source in SOURCES:
        print(f"\n[SCAN] {source['name']}")
        items = scan_source(source)
        total_found += len(items)
        for item in items:
            if insert_opportunity(item):
                total_new += 1
                print(f"[NEW] {item['score']:03d} | {item['title'][:100]}")
    print(f"\nRISULTATO: trovati={total_found} nuovi={total_new}")
    return total_new

if __name__ == "__main__":
    run_scan()
