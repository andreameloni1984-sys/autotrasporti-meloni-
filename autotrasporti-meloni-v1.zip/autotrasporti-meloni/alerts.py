import requests
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
from database import get_new_unnotified, mark_notified

def send_telegram(message):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("[INFO] Telegram non configurato")
        return False
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "disable_web_page_preview": True}
    try:
        response = requests.post(url, json=payload, timeout=20)
        response.raise_for_status()
        return True
    except Exception as exc:
        print(f"[ERROR] Telegram: {exc}")
        return False

def format_opportunity(row):
    return (
        "🚛 AUTOTRASPORTI MELONI\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🎯 {row['title']}\n\n"
        f"📊 Rilevanza: {row['score']}/100\n"
        f"📂 {row['category']}\n"
        f"📌 Stato: {row['status']}\n"
        f"🏛 Fonte: {row['source']}\n\n"
        f"🔗 {row['url']}"
    )

def send_new_alerts(limit=10):
    rows = get_new_unnotified(limit)
    sent = 0
    for row in rows:
        if send_telegram(format_opportunity(row)):
            mark_notified(row["id"])
            sent += 1
    return sent
